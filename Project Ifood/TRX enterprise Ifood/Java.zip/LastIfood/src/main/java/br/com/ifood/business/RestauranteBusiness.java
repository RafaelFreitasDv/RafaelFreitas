package br.com.ifood.business;

import java.util.ArrayList;
import java.util.List;

import br.com.ifood.model.Restaurante;

public class RestauranteBusiness {
	
	public List<Restaurante> listarTodos() {
		
		List<Restaurante> lista = new ArrayList<Restaurante>();
		
		Restaurante resBean = new Restaurante();
		resBean.setId(1);
		resBean.setNome("Japa Vegano");
		resBean.setCategoria("Japonesa");
		resBean.setDescricao("N�o tem mais desculpa, japa sem peixe � bom simm, venha nos conhecer.");
		resBean.setCnpj("43.443.761/0024-17");
		resBean.setTel("(11)97654-9867");
		resBean.setEndereco("Rua Amilio Diniz, 34");
		lista.add(resBean);
		
		resBean = new Restaurante();
		resBean.setId(2);
		resBean.setNome("Mobi ");
		resBean.setCategoria("Hamburguer Artesanal");
		resBean.setDescricao("Eleita a melhor hamburgueria por n�s mesmos.");
		resBean.setCnpj("32.955.399/0001-50");
		resBean.setTel("(11)95554-5467");
		resBean.setEndereco("Rua Marechal Olivio, 374");
		lista.add(resBean);
		
		resBean = new Restaurante();
		resBean.setId(3);
		resBean.setNome("Tortas Mara");
		resBean.setCategoria("Doces");
		resBean.setDescricao("Pe�a j� as melhores tortas da zona Sul, feitas com muito amor.");
		resBean.setCnpj("55.967.380/0001-20");
		resBean.setTel("(21)96221-9867");
		resBean.setEndereco("Rua Capiravi, 250");
		lista.add(resBean);
		
		resBean = new Restaurante();
		resBean.setId(4);
		resBean.setNome("Giovanni Tratoria");
		resBean.setCategoria("Italiana");
		resBean.setDescricao("Conhe�a as melhores massas artesanais, feitas pelo Signore Giovanni.");
		resBean.setCnpj("35.771.881/0001-29");
		resBean.setTel("(41)97629-2213");
		resBean.setEndereco("Avenida Tavres Moreira, 1089");
		lista.add(resBean);
		return lista;

}
	public void gravar(Restaurante restauranteBean) {
		System.out.println("Edi��o efetuada com sucesso:" + restauranteBean.getNome());
	}
}
