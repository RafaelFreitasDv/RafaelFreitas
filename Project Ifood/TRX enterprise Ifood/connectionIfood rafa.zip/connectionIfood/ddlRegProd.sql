--  INSERT INTO tabela de Registro de Produtos  (T_REG_PROD)
INSERT INTO T_REG_PROD (
        ID_REG_PROD, T_REST_ID_REST, T_PROD_ID_PROD, DS_PROD, VL_PROD
    )
    VALUES (
        1, 1, 13, 'Feijoada completa que serve duas pessoas', 35.00
    );
    
INSERT INTO T_REG_PROD (
        ID_REG_PROD, T_REST_ID_REST, T_PROD_ID_PROD, DS_PROD, VL_PROD
    )
    VALUES (
        2, 2, 3, 'X-salada do gord�o', 25.00
    );

INSERT INTO T_REG_PROD (
        ID_REG_PROD, T_REST_ID_REST, T_PROD_ID_PROD, DS_PROD, VL_PROD
    )
    VALUES (
        3, 4, 3, 'X-salada que salva o dia', 45.00
    );
    
