--  INSERT INTO tabela restaurante  (T_REST)
INSERT INTO T_REST (
        ID_REST, NR_CNPJ, NM_REST, NM_CATG, DS_REST, NR_TEL, DS_END
    )
    VALUES (
        1, 20384580000175, 'Saborzin', 'Comida Bahiana', 'Vem neném vem!', '(11)3333-2222', 'Rua Dante Battiston, 110 - Centro - OZasco - SP - 06013-030'
    );
    
INSERT INTO T_REST (
        ID_REST, NR_CNPJ, NM_REST, NM_CATG, DS_REST, NR_TEL, DS_END
    )
    VALUES (
        2, 20384580000176, 'Gordo Lanches', 'Lanches', 'Felicidade e gordura!', '(11)4483-2222', 'Rua do Bacon, 40 - Centro - OZasco - SP - 06013-020'
    );
    
INSERT INTO T_REST (
        ID_REST, NR_CNPJ, NM_REST, NM_CATG, DS_REST, NR_TEL, DS_END
    )
    VALUES (
        3, 20384580000177, 'Baconeiros', 'Lanches', 'Carne su�na de qualidade!', '(11)3342-5576', 'Rua de tr�s, 32 - Oeste - OZasco - SP - 06013-030'
    );

INSERT INTO T_REST (
        ID_REST, NR_CNPJ, NM_REST, NM_CATG, DS_REST, NR_TEL, DS_END
    )
    VALUES (
        4, 20384580000178, 'Hero Burguer', 'Lanches', 'Salvando o seu dia!', '(11)5841-8978', 'Av. Gotham, 320 - Leste - OZasco - SP - 48743-030'
    );
    
INSERT INTO T_REST (
        ID_REST, NR_CNPJ, NM_REST, NM_CATG, DS_REST, NR_TEL, DS_END
    )
    VALUES (
        5, 20384580000179, 'Harry Lanches', 'Lanches', 'Wingardium Leviossa!', '(11)93493-4934', 'Beco Diagonal 122 - norte - Hogwarts - SP - 48743-030'
    );
    
