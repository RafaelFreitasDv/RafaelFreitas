-- INSERT INTO tabala de Cliente    (T_CLIENTE)
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        1, 'Carlos Daniel Bracho', 'Av. Monterrey, 1.998 - Centro - OZasco - SP - 02407-998'
    );

INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        2, 'Paola Montaner Bracho', 'Av. Monterrey, 1.998 - Centro - OZasco - SP - 02407-998'
    );

INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        3, 'Paulina Martins', 'Estr. Cuernavaca, 1.972 - Centro - OZasco - SP - 01207-971'
    );

INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        4, 'Mauro Cesar', 'Rua Amacas, 320 - Sul - S�o Paulo - SP - 05896-852'
    );
    
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        5, 'Gabriel Medica', 'Rua do Surf, 005 - leste - OZasco - SP - 04587-971'
    );
    
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        6, 'Jessica Gomes', 'Estr. Itapecerica, 484 - Centro - OZasco - SP - 78417-971'
    );
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        7, 'Sergio Reis', 'Av. Sert�o, 46 - Oeste - OZasco - SP - 04858-950'
    );
    
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        8, 'Marilia Boeing', 'Rua Petroleiros - Sul - OZasco - SP - 98548-950'
    );
    
INSERT INTO T_CLIENTE (
        ID_CLIENTE, NM_CLIENTE, DS_END
    )
    VALUES (
        9, 'Pedro Bial', 'Estrada Famas - Oeste - OZasco - SP - 04788-950'
    );