--  DROPS da tabelas 
/*
DROP TABLE T_AVALIACAO CASCADE CONSTRAINTS;
DROP TABLE T_CAT_PROD CASCADE CONSTRAINTS;
DROP TABLE T_CLIENTE CASCADE CONSTRAINTS;
DROP TABLE T_PEDIDOS CASCADE CONSTRAINTS;
DROP TABLE T_PROD CASCADE CONSTRAINTS;
DROP TABLE T_REG_PROD CASCADE CONSTRAINTS;
DROP TABLE T_REST CASCADE CONSTRAINTS;
*/

--  CRIANDO as tabelas
CREATE TABLE t_avaliacao (
    id_avaliacao   NUMBER(9) NOT NULL,
    t_rest_id_rest NUMBER(9) NOT NULL,
    nt_avaliacao   NUMBER(1),
    ds_avaliacao   VARCHAR2(120)
);
ALTER TABLE t_avaliacao ADD CONSTRAINT t_avaliacao_pk PRIMARY KEY ( id_avaliacao );

CREATE TABLE t_cat_prod (
    id_cat_prod NUMBER(2) NOT NULL,
    nm_cat_prod VARCHAR2(20) NOT NULL
);
ALTER TABLE t_cat_prod ADD CONSTRAINT t_cat_prod_pk PRIMARY KEY ( id_cat_prod );

CREATE TABLE t_cliente (
    id_cliente NUMBER(9) NOT NULL,
    nm_cliente VARCHAR2(50) NOT NULL,
    ds_end     VARCHAR2(50) NOT NULL
);
ALTER TABLE t_cliente ADD CONSTRAINT t_cliente_pk PRIMARY KEY ( id_cliente );

CREATE TABLE t_pedidos (
    id_pedido                NUMBER(9) NOT NULL,
    t_cliente_id_cliente     NUMBER(9) NOT NULL,
    t_reg_prod_id_reg_prod   NUMBER(9) NOT NULL,
    t_avaliacao_id_avaliacao NUMBER(9) NOT NULL,
    vl_taxa_entr             NUMBER(5, 2) NOT NULL,
    qt_prod                  NUMBER(2) NOT NULL,
    vl_total                 NUMBER(5, 2) NOT NULL
);
ALTER TABLE t_pedidos ADD CONSTRAINT t_pedidos_pk PRIMARY KEY ( id_pedido );

CREATE TABLE t_prod (
    id_prod                NUMBER(9) NOT NULL,
    t_cat_prod_id_cat_prod NUMBER(2) NOT NULL,
    nm_prod                VARCHAR2(20) NOT NULL
);
ALTER TABLE t_prod ADD CONSTRAINT t_prod_pk PRIMARY KEY ( id_prod );

CREATE TABLE t_reg_prod (
    id_reg_prod    NUMBER(9) NOT NULL,
    t_rest_id_rest NUMBER(9) NOT NULL,
    t_prod_id_prod NUMBER(9) NOT NULL,
    ds_prod        VARCHAR2(50) NOT NULL,
    vl_prod        NUMBER(5, 2) NOT NULL
);
ALTER TABLE t_reg_prod ADD CONSTRAINT t_reg_prod_pk PRIMARY KEY ( id_reg_prod );

CREATE TABLE t_rest (
    id_rest NUMBER(9) NOT NULL,
    nr_cnpj VARCHAR2(18) NOT NULL,
    nm_rest VARCHAR2(30) NOT NULL,
    nm_catg VARCHAR2(20) NOT NULL,
    ds_rest VARCHAR2(120) NOT NULL,
    nr_tel  VARCHAR2(14) NOT NULL,
    ds_end  VARCHAR2(120) NOT NULL
);

--  Adicionando CONTRAINTS PRIMARY e FOREIGN KEY
ALTER TABLE t_rest ADD CONSTRAINT t_rest_pk PRIMARY KEY ( id_rest );

ALTER TABLE t_avaliacao
    ADD CONSTRAINT t_avaliacao_t_rest_fk FOREIGN KEY ( t_rest_id_rest )
        REFERENCES t_rest ( id_rest );

ALTER TABLE t_pedidos
    ADD CONSTRAINT t_pedidos_t_avaliacao_fk FOREIGN KEY ( t_avaliacao_id_avaliacao )
        REFERENCES t_avaliacao ( id_avaliacao );

ALTER TABLE t_pedidos
    ADD CONSTRAINT t_pedidos_t_cliente_fk FOREIGN KEY ( t_cliente_id_cliente )
        REFERENCES t_cliente ( id_cliente );

ALTER TABLE t_pedidos
    ADD CONSTRAINT t_pedidos_t_reg_prod_fk FOREIGN KEY ( t_reg_prod_id_reg_prod )
        REFERENCES t_reg_prod ( id_reg_prod );

ALTER TABLE t_prod
    ADD CONSTRAINT t_prod_t_cat_prod_fk FOREIGN KEY ( t_cat_prod_id_cat_prod )
        REFERENCES t_cat_prod ( id_cat_prod );

ALTER TABLE t_reg_prod
    ADD CONSTRAINT t_reg_prod_t_prod_fk FOREIGN KEY ( t_prod_id_prod )
        REFERENCES t_prod ( id_prod );
        
        
alter table t_cliente
modify ds_end varchar2(120);