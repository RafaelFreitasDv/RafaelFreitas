--  INSERT INTO tabela Categoria de Produtos    (T_CAT_PROD)
INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        1, 'Pizza'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        2, 'Hamburguer'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        3, 'Massas'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        4, 'Temaki'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        5, 'Sushi'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        6, 'Sashimi'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        7, 'Caseira'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        8, 'Marmitex'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        9, 'Executivo'
    );

INSERT INTO T_CAT_PROD (
        ID_CAT_PROD, NM_CAT_PROD
    )
    VALUES (
        10, 'Torta'
    );