-- INSET INTO tabela de Produtos
INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        1, 1, 'Calabresa'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        2, 1, 'Portuguesa'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        3, 2, 'X-Salada'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        4, 2, 'X-Bacon'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        5, 3, 'Cannelloni'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        6, 3, 'Lasanha'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        7, 4, 'Salmão completo'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        8, 4, 'Califórnia'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        9, 5, 'Uramaki'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        10, 5, 'Salmão'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        11, 6, 'Atum'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        12, 6, 'Prego'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        13, 7, 'Feijoada'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        14, 7, 'Rabada'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        15, 8, 'Calabresa acebolada'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        16, 8, 'Omelete'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        17, 9, 'Picadinho'
    );

 INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        18, 9, 'Vira à paulista'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        19, 10, 'Frango'
    );

INSERT INTO T_PROD (
        ID_PROD, T_CAT_PROD_ID_CAT_PROD, NM_PROD
    )
    VALUES (
        20, 10, 'Chocolate'
    );