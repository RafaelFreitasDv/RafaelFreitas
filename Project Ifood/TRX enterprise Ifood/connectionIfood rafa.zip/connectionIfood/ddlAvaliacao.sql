--  INSERT INTO Tabela de Avaliações    (T_AVALIACAO)
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        1, 1, 4, 'A feijoada até que é boa, mas não satisfaz duas pessoas. Kkkk...'
    );

INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        2, 1, 5, 'Com toda certeza a melhor feijoada da região! s2'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        3, 3, 4.5 , 'Gostei demais'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        4, 3, 5 , 'Estava delicioso'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        5, 3, 3 , 'Muito bom'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        6, 3, 5, ':)'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        7, 4, 4.5 , 'Delicia'
    );

INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        8, 4, 3 , 'Muita gordura'
    );
    
 INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        8, 4, 5 , 'Muito grande, adorei!
        '
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        9, 4, 5 , 'Sou f�'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        10, 4, 2 , 'pouco sabor'
    );

INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        11, 5, 5 , 'Adorei o lanche tem�tico'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        11, 5, 3 , 'Muito bom o atendimento mas o lanche veio com pouco bacon'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        12, 5, 4.5 , 'Minhas filhas adoraram'
    );
    
INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        13, 5, 4.5 , 'pedirei de novo'
    );

INSERT INTO T_AVALIACAO (
        ID_AVALIACAO, T_REST_ID_REST, NT_AVALIACAO, DS_AVALIACAO
    )
    VALUES(
        14, 5, 3 , 'poderia ter mais op��es'
    ); 
    
       

    
    
